class InstanceVariable {
    int x = 10;

    public static void main(String[] args) {
        InstanceVariable obj = new InstanceVariable();
        System.out.println(obj.x);
    }
}
