class CmdArray {
    public static void main(String[] args) {
        String[] arr = args;

        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}

